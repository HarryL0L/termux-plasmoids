import QtQuick
import org.kde.plasma.plasma5support as P5Support

Item {
    id: root

    property bool connected: false
    property string ssid: ""
    property int rssi: -100
    property string ip: ""
    property int linkSpeed: 0
    property string icon: "network-wireless-offline"

    function updateState() {
        if (!ip || ip === "0.0.0.0") {
            connected = false
            icon = "network-wireless-offline"
            return
        }

        connected = true

        var strength = Math.min(
                    100,
                    Math.max(
                        0,
                        Math.round((rssi + 100))
                    )
                )

        if (strength < 25)
            icon = "network-wireless-signal-weak"
        else if (strength < 50)
            icon = "network-wireless-signal-ok"
        else if (strength < 75)
            icon = "network-wireless-signal-good"
        else
            icon = "network-wireless-signal-excellent"
    }

    P5Support.DataSource {
        id: exec
        engine: "executable"

        onNewData: function(source, data) {
            disconnectSource(source)

            var out = data["stdout"]

            if (!out || out.trim().length === 0) {
                root.connected = false
                root.icon = "network-wireless-offline"
                return
            }

            try {
                var obj = JSON.parse(out.trim())

                root.ssid = obj.ssid || ""
                root.rssi = obj.rssi || -100
                root.ip = obj.ip || ""
                root.linkSpeed = obj.link_speed || 0

                root.updateState()

            } catch(e) {
                root.connected = false
                root.icon = "network-wireless-offline"
            }
        }
    }

    function refresh() {

        var cmd =
            "termux-wifi-connectioninfo"

        exec.connectSource(cmd)
    }

    Component.onCompleted: refresh()
}