import QtQuick
import org.kde.plasma.plasmoid
import org.kde.kirigami as Kirigami
import org.kde.plasma.components 3.0 as PlasmaComponents
import "providers"

PlasmoidItem {
    id: root

    WifiProvider {
        id: wifi
    }

    preferredRepresentation: compactRepresentation

    compactRepresentation: Item {
        implicitWidth: Kirigami.Units.iconSizes.smallMedium
        implicitHeight: Kirigami.Units.iconSizes.smallMedium

        Kirigami.Icon {
            anchors.fill: parent
            source: wifi.icon
            color: wifi.connected ? Kirigami.Theme.textColor : Kirigami.Theme.negativeTextColor
        }

        MouseArea {
            anchors.fill: parent
            onClicked: root.expanded = !root.expanded
        }
    }

    fullRepresentation: Item {
        implicitWidth: Kirigami.Units.gridUnit * 22
        implicitHeight: Kirigami.Units.gridUnit * 9

        Column {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.largeSpacing
            spacing: Kirigami.Units.smallSpacing

            PlasmaComponents.Label {
                text: "WiFi Status"
                font.bold: true
            }

            PlasmaComponents.Label {
                text: "Status: " + (wifi.connected ? "Connected" : "Disconnected")
                color: wifi.connected ? Kirigami.Theme.textColor : Kirigami.Theme.negativeTextColor
            }

            PlasmaComponents.Label {
                visible: wifi.connected
                text: "SSID: " + wifi.ssid
            }

            PlasmaComponents.Label {
                visible: wifi.connected
                text: "IP: " + wifi.ip
            }

            PlasmaComponents.Label {
                visible: wifi.connected
                text: "Signal: " + (2 * (wifi.rssi + 100)) + "%"
            }

            PlasmaComponents.Label {
                visible: wifi.connected
                text: "Link Speed: " + wifi.linkSpeed + " Mbps"
            }
        }
    }

    Timer {
        interval: 10000
        repeat: true
        running: true
        onTriggered: wifi.refresh()
    }
}
